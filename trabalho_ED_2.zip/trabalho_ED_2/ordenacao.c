#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include "ordenacao.h"


void grava_aleatorio_100(){ // Fun��o que grava no arquivo 100 numeros aleatorios
    FILE *arquivo;
    int aleatorio;
    int i;

    arquivo = fopen("aleatorio_100.txt","w"); // Abre o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    //Gera n�mero aleat�rio
    srand( (unsigned)time(NULL) );

    for(i=0 ; i < 100 ; i++){
        aleatorio = rand();
        fprintf(arquivo,"%d\n", aleatorio);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}

void grava_aleatorio_1000(){ // Fun��o que grava no arquivo
    FILE *arquivo;
    int aleatorio;
    int i;

    arquivo = fopen("aleatorio_1000.txt", "w"); // Abre o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    //Gera n�mero aleat�rio
    srand( (unsigned)time(NULL) );

    for(i=0 ; i < 1000 ; i++){
        aleatorio = rand();
        fprintf(arquivo,"%d  ", aleatorio);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}

void grava_aleatorio_10000(){ // Fun��o que grava no arquivo
    FILE *arquivo;
    int aleatorio;
    int i;

    arquivo = fopen("aleatorio_10000.txt", "w"); // Abre o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    //Gera n�mero aleat�rio
    srand( (unsigned)time(NULL) );

    for(i=0 ; i < 10000 ; i++){
        aleatorio = rand();
        fprintf(arquivo,"%d  ", aleatorio);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}

void grava_aleatorio_100000(){ // Fun��o que grava no arquivo
    FILE *arquivo;
    int aleatorio;
    int i;

    arquivo = fopen("aleatorio_100000.txt", "w"); // Abre o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    //Gera n�mero aleat�rio
    srand( (unsigned)time(NULL) );

    for(i=0 ; i < 100000 ; i++){
        aleatorio = rand();
        fprintf(arquivo,"%d  ", aleatorio);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}


void grava_ordenado_100(int *v){
    FILE *arquivo;
    int i, num;

    arquivo = fopen("ordenado_100.txt","w"); // cria o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    for(i=0 ; i < 100 ; i++){
        num = v[i];
        fprintf(arquivo,"%d  ", num);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}

void grava_ordenado_1000(int *v){
    FILE *arquivo;
    int i, num;

    arquivo = fopen("ordenado_1000.txt","w"); // cria o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    for(i=0 ; i < 1000 ; i++){
        num = v[i];
        fprintf(arquivo,"%d  ", num);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}

void grava_ordenado_10000(int *v){
    FILE *arquivo;
    int i, num;

    arquivo = fopen("ordenado_10000.txt","w"); // cria o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    for(i=0 ; i < 10000 ; i++){
        num = v[i];
        fprintf(arquivo,"%d  ", num);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}

void grava_ordenado_100000(int *v){
    FILE *arquivo;
    int i, num;

    arquivo = fopen("ordenado_100000.txt","w"); // cria o arquivo
    printf("\n");

    if (arquivo == NULL){
        printf("Problemas ao tentar criar o arquivo\n");
    }

    for(i=0 ; i < 100000; i++){
        num = v[i];
        fprintf(arquivo,"%d  ", num);
    }

    system("cls");
    fclose(arquivo); // Fecha o arquivo
}


void select_sort(int *v, int TAM){
    int menor, aux, temp, troca;

    // Percorre todo o vetor at� TAM-1, pois a �ltima posi��o n�o precisa testar pois j� estar� ordenada;
    for(aux=0; aux < TAM-1; aux++){
        menor = aux; // Menor valor recebe a posi��o que est� passando;
        // Percorre o vetor da posi��o aux+1 at� o final;
        for (temp=aux+1; temp < TAM; temp++){
            // Testa se a posi��o que est� passando � menor que o menor valor;
            if (v[temp] < v[menor]){
                menor = temp; // menor recebe a posi��o do menor valor;
            }
        }

        // Se a posi��o for diferente da que est� passando, ocorre a troca;
        if (menor != aux){
            troca = v[aux];
            v[aux] = v[menor];
            v[menor] = troca;
        }
    }
    if(TAM==100){
        grava_ordenado_100(v);
    }else if(TAM==1000){
        grava_ordenado_1000(v);
    }else if(TAM==10000){
        grava_ordenado_10000(v);
    }else if(TAM==100000){
        grava_ordenado_100000(v);
    }else{
        printf("Tamanho inv�lido");
    }
}

void insertion_sort(int *array, int TAM) {
    int i, j, tmp;
    for (i = 1; i < TAM; i++) {
        j = i;
        while (j > 0 && array[j - 1] > array[j]) {
              tmp = array[j];
              array[j] = array[j - 1];
              array[j - 1] = tmp;
              j--;
        }
    }
    if(TAM==100){
        grava_ordenado_100(array);
    }else if(TAM==1000){
        grava_ordenado_1000(array);
    }else if(TAM==10000){
        grava_ordenado_10000(array);
    }else if(TAM==100000){
        grava_ordenado_100000(array);
    }else{
        printf("Tamanho inv�lido");
    }
}

void bubble_sort(int *v, int TAM){
    int aux;
    int temp;
    int troca;

    // Percorre o vetor de tr�s para a frente
    for( aux = TAM-1; aux >= 0;aux-- ){
        // Percorre o vetor de frente para tr�s, at� a posi��o que est� passando no primeiro "for", ou seja, cada vez que passar pelo primeiro "for" ele vai testar uma posi��o a menos aqui.
       for( temp = 0; temp < aux; temp++ ){
            // Testa se a posi��o que est� passando � maior que a pr�xima, se for ocorre a troca
           if( v[temp] > v[temp+1] ){
                // Manda o valor atual para uma vari�vel aux
                troca = v[temp];
                // Manda o pr�ximo valor para a posi��o atual
                v[temp] = v[temp+1];
                // Manda a vari�vel aux, com o valor da posi��o atual, para a pr�xima posi��o
                v[temp+1] = troca;
           }
        }
    }

    if(TAM==100){
        grava_ordenado_100(v);
    }else if(TAM==1000){
        grava_ordenado_1000(v);
    }else if(TAM==10000){
        grava_ordenado_10000(v);
    }else if(TAM==100000){
        grava_ordenado_100000(v);
    }else{
        printf("Tamanho inv�lido");
    }

}

void quick_sort(int *v, int left, int right) {
    int i, j, x, y;

    i = left;
    j = right;
    x = v[(left + right) / 2];

    while(i <= j) {
        while(v[i] < x && i < right) {
            i++;
        }
        while(v[j] > x && j > left) {
            j--;
        }
        if(i <= j) {
            y = v[i];
            v[i] = v[j];
            v[j] = y;
            i++;
            j--;
        }
    }

    if(j > left) {
        quick_sort(v, left, j);
    }
    if(i < right) {
        quick_sort(v, i, right);
    }

}


void merge(int *vetor, int comeco, int meio, int fim) {
    int com1 = comeco, com2 = meio+1, comAux = 0, tam = fim-comeco+1;
    int *vetAux;
    vetAux = (int*)malloc(tam * sizeof(int));

    while(com1<=meio && com2<=fim){
        if(vetor[com1] <= vetor[com2]){
            vetAux[comAux] = vetor[com1];
            com1++;
        }else{
            vetAux[comAux] = vetor[com2];
            com2++;
        }
        comAux++;
    }

    while(com1<=meio){  //Caso ainda haja elementos na primeira metade
        vetAux[comAux] = vetor[com1];
        comAux++;com1++;
    }

    while(com2<=fim){   //Caso ainda haja elementos na segunda metade
        vetAux[comAux] = vetor[com2];
        comAux++;com2++;
    }

    for(comAux=comeco;comAux<=fim;comAux++){    //Move os elementos de volta para o vetor original
        vetor[comAux] = vetAux[comAux-comeco];
    }

    free(vetAux);

}


void mergeSort(int *vetor, int comeco, int fim){
    if (comeco < fim) {
        int meio = (fim+comeco)/2;
        mergeSort(vetor, comeco, meio);
        mergeSort(vetor, meio+1, fim);
        merge(vetor, comeco, meio, fim);
    }
}

void inserir_vetor(FILE *arquivo, int *vet, int tam){
    int i=0, num;
    while((fscanf(arquivo,"%d\n",&num)) != EOF){
        vet[i]= num;
        i++;
    }
}

