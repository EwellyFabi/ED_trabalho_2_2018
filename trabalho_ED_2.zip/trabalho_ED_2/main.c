#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include "ordenacao.h"

int main(){

    FILE *arquivo;
    int opcao = 0;
    int vet100[100];
    int vet1000[1000];
    int vet10000[10000];
    int vet100000[100000];

    while(1==1){
        printf("\nMenu");
        printf("\n1-Selection sort");
        printf("\n2-Insertion sort");
        printf("\n3-Bubble sort");
        printf("\n4-Quick sort");
        printf("\n5-Merge sort");
        printf("\n0-Sair");
        printf("\nDigite a opcao desejada : ");
        scanf("%d",&opcao);

        grava_aleatorio_100();
        grava_aleatorio_1000();
        grava_aleatorio_10000();
        grava_aleatorio_100000();

        if ( opcao == 0 ){
            break;
        }else if ( opcao == 1 ){
            arquivo = fopen("aleatorio_100.txt","r");
            inserir_vetor(arquivo,vet100,100);
            select_sort(vet100,100);
            fclose(arquivo);

            arquivo = fopen("aleatorio_1000.txt","r");
            inserir_vetor(arquivo,vet1000,1000);
            select_sort(vet1000,1000);
            fclose(arquivo);

            arquivo = fopen("aleatorio_10000.txt","r");
            inserir_vetor(arquivo,vet10000,10000);
            select_sort(vet10000,10000);
            fclose(arquivo);

            arquivo = fopen("aleatorio_100000.txt","r");
            inserir_vetor(arquivo,vet100000,100000);
            select_sort(vet100000,100000);
            fclose(arquivo);

        }else if ( opcao == 2 ){
            arquivo = fopen("aleatorio_100.txt","r");
            inserir_vetor(arquivo,vet100,100);
            insertion_sort(vet100,100);
            fclose(arquivo);

            arquivo = fopen("aleatorio_1000.txt","r");
            inserir_vetor(arquivo,vet1000,1000);
            insertion_sort(vet1000,1000);
            fclose(arquivo);

            arquivo = fopen("aleatorio_10000.txt","r");
            inserir_vetor(arquivo,vet10000,10000);
            insertion_sort(vet10000,10000);
            fclose(arquivo);

            arquivo = fopen("aleatorio_100000.txt","r");
            inserir_vetor(arquivo,vet100000,100000);
            insertion_sort(vet100000,100000);
            fclose(arquivo);


        }else if ( opcao == 3 ){
            arquivo = fopen("aleatorio_100.txt","r");
            inserir_vetor(arquivo,vet100,100);
            bubble_sort(vet100,100);
            fclose(arquivo);

            arquivo = fopen("aleatorio_1000.txt","r");
            inserir_vetor(arquivo,vet1000,1000);
            bubble_sort(vet1000,1000);
            fclose(arquivo);

            arquivo = fopen("aleatorio_10000.txt","r");
            inserir_vetor(arquivo,vet10000,10000);
            bubble_sort(vet10000,10000);
            fclose(arquivo);

            arquivo = fopen("aleatorio_100000.txt","r");
            inserir_vetor(arquivo,vet100000,100000);
            bubble_sort(vet100000,100000);
            fclose(arquivo);

        }else if ( opcao == 4 ){
            arquivo = fopen("aleatorio_100.txt","r");
            inserir_vetor(arquivo,vet100,100);
            quick_sort(vet100,0,100);
            fclose(arquivo);
            grava_ordenado_100(vet100);

            arquivo = fopen("aleatorio_1000.txt","r");
            inserir_vetor(arquivo,vet1000,1000);
            quick_sort(vet1000,0,1000);
            fclose(arquivo);
            grava_ordenado_1000(vet1000);

            arquivo = fopen("aleatorio_10000.txt","r");
            inserir_vetor(arquivo,vet10000,10000);
            quick_sort(vet10000,0,10000);
            fclose(arquivo);
            grava_ordenado_10000(vet10000);

            arquivo = fopen("aleatorio_100000.txt","r");
            inserir_vetor(arquivo,vet100000,100000);
            quick_sort(vet100000,0,100000);
            fclose(arquivo);
            grava_ordenado_100000(vet100000);

        }else if ( opcao == 5 ){
            arquivo = fopen("aleatorio_100.txt","r");
            inserir_vetor(arquivo,vet100,100);
            mergeSort(vet100,0,100);
            fclose(arquivo);
            grava_ordenado_100(vet100);

            arquivo = fopen("aleatorio_1000.txt","r");
            inserir_vetor(arquivo,vet1000,1000);
            mergeSort(vet1000,0,1000);
            fclose(arquivo);
            grava_ordenado_1000(vet1000);

            arquivo = fopen("aleatorio_10000.txt","r");
            inserir_vetor(arquivo,vet10000,10000);
            mergeSort(vet10000,0,10000);
            fclose(arquivo);
            grava_ordenado_10000(vet10000);

            arquivo = fopen("aleatorio_100000.txt","r");
            inserir_vetor(arquivo,vet100000,100000);
            mergeSort(vet100000,0,100000);
            fclose(arquivo);
            grava_ordenado_100000(vet100000);

        }else{
            printf("\nOpcao Invalida!\n");
            Sleep(500);
            system("cls");
        }

    }
    return 0;
}
