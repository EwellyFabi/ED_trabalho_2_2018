#ifndef ORDENACAO_H_INCLUDED
#define ORDENACAO_H_INCLUDED

void grava_aleatorio_100();

void grava_aleatorio_1000();

void grava_aleatorio_10000();

void grava_aleatorio_100000();

void grava_ordenado_100(int *v);

void grava_ordenado_1000(int *v);

void grava_ordenado_10000(int *v);

void grava_ordenado_100000(int *v);

void select_sort(int *v, int TAM);

void insertion_sort(int *array, int TAM);

void bubble_sort(int *v, int TAM);

void quick_sort(int *v, int left, int right);

void merge(int *vetor, int comeco, int meio, int fim);

void mergeSort(int *vetor, int comeco, int fim);

void inserir_vetor(FILE *arquivo, int *vet, int tam);

#endif // ORDENACAO_H_INCLUDED
